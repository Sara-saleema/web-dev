<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "carstore";
// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
	
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$query = "SELECT * FROM customer where name='$name' and phone_no='$phone'";
	$result = mysqli_query($conn,$query);
	$row=mysqli_fetch_array($result);
	if ($row['name']==$name && $row['phone_no']==$phone)
	{	
		echo "search successfully", mysqli_error($conn);
		echo '<a href="../booking_insert.html" class="btn">  SUBMIT</a>';
	}
	
	else{
		echo "invalid search";
	}
	
} 

?>