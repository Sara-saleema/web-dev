<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "carstore";
// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
	
	$username = $_POST['username'];
	$password = $_POST['password'];
	$query = "SELECT * FROM signin where username='$username' and password='$password'";
	$result = mysqli_query($conn,$query);
	$row=mysqli_fetch_array($result);
	if ($row['username']==$username && $row['password']==$password)
	{	
		echo "logged in";
		header("Location: ../inputform.html");
	}
	else{
		echo "<script>alert('invalid user');window.location.href='../login.html';</script>";
	}
	
} 

?>