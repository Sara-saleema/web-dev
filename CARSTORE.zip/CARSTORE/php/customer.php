<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "carstore";

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
	$name= $_POST['name'];
	$email= $_POST['email'];
	$gender= $_POST['gender'];
    $password = $_POST['password'];
	$phone_no = $_POST['phone_no'];
	$address = $_POST['address'];
	$sql = "INSERT INTO customer (name, email, gender, password, phone_no, address) VALUES ('$name','$email','$gender','$password','$phone_no','$address')";
	$sql1 = "INSERT INTO booking (customername,customerphone_no) VALUES ('$name','$phone_no')";
	$conn->query($sql1);
	if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
	header("Location: ../cardetails.html");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>