<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "carstore";

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
	$id= $_POST['car_id'];
	$carname= $_POST['car_name'];
    $customer_name = $_POST['customer_name'];
	$phone_no = $_POST['phone_no'];
	$repair_services = $_POST['repair_services'];
	$sql = "INSERT INTO repair (car_id,car_name,customer_name,phone_no,repair_services) VALUES ('$id','$carname','$customer_name','$phone_no','$repair_services')";
	if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>