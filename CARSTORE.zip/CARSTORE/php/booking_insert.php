<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "carstore";

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
	
	$carid = $_POST['car_id'];
	$bookingdate = $_POST['booking_date'];
	$bookingtime = $_POST['booking_time'];
	$sql = "INSERT INTO booking (carid, bookingdate, bookingtime) VALUES ('$carid','$bookingdate','$bookingtime')";
	if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>

