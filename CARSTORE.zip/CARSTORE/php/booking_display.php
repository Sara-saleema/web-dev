<html>
<head>
<title>booking</title>
<link href="../style.css" rel="stylesheet" type="text/css">
<style>
table, td, th {  
  border: 1px solid Black;
  text-align: left;
  color: white;
}

table {
  border-collapse: collapse;
  width: 100%;
  align: left;
}

th, td , input{
  padding: 3px;

}
</style>
</head>
<body background='../images/image8.jpg'>
<form action="operations.php" method="post">
    <div class="booking-box">

	  <h1>BOOKING</h1>
	  <br>
	  <table>
	  <tr>
		<th>CARID</th>
		<th>CAR</th>
	    <th>CAR COST</th>
		<th>NAME</th>
		<th>PHONE</th>
		<th>BOOKING DATE</th>
		<th>BOOKING TIME</th>
		<th>PAYMENT TYPE</th>
	  </tr>
<?php
$conn=mysqli_connect("localhost","root","","carstore");
if ($conn-> connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM booking";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {		
		echo 
		"<tr><td><input type='text' name='car_id' value='" . $row["car_id"].
		"'</td><td><input type='text' name='carmodel' value='" . $row["carmodel"].
		"'</td><td><input type='text' name='cost' value='" . $row["cost"].
		"'</td><td><input type='text' name='customername' value='" . $row["customername"].
		"'</td><td><input type='text' name='customerphone_no' value='" . $row["customerphone_no"].
		"'</td><td><input type='text' name='booking_date' value='" . $row["booking_date"].
		"'</td><td><input type='text' name='booking_time' value='" . $row["booking_time"].
		"'</td><td><input type='text' name='paymentmode' value='" . $row["paymentmode"]."'</td></tr>";
		}
	echo "</table>";
}else{
	echo"zero rows";
}
$conn->close();
?><div style="text-align:center">
<br><br>
<h2> Enter below to delete the record</h2>
	  <input type="text" id="book" placeholder="Enter customer_name" name="customername" required>
	  <br>
	  <input type="text" id="book" placeholder="Enter phone" name="customerphone" required>
	  <br>
	   <input class="btn" type="submit" name="Submit" value="DELETE">
	  <br></div>

</div>
</form>

</body>
</html>