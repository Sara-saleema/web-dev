<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "carstore";

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
	
	$carid = $_POST['car_id'];
	$bookingdate = $_POST['booking_date'];
	$bookingtime = $_POST['booking_time'];
	$sql = "DELETE FROM booking where carid='$carid' and bookingdate='$bookingdate' and bookingtime='$bookingtime'";
	if ($conn->query($sql) === TRUE) {
    echo "record deleted successfully";

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>

