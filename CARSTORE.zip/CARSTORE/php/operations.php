<?php
include_once("operations.php");
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "carstore";
// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
	   
	$customername = $_POST['customername'];
	$customerphone = $_POST['customerphone'];
	
	$sql = "delete from booking WHERE customername='$customername' and customerphone_no='$customerphone'";
	$conn->query($sql);
	if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
	;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

}
$conn->close();

?>