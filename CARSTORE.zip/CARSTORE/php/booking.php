<?php
session_start();
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "carstore";
// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
	
	$carid = $_POST['carid'];
	$carmodel = $_POST['carmodel'];
	$carcost = $_POST['carcost'];
	$customername = $_POST['customername'];
	$customerphone = $_POST['customerphone'];
	$payment = $_POST['payment'];
	
	$sql = "UPDATE booking SET car_id='$carid', carmodel='$carmodel', cost='$carcost', booking_date=CURDATE(), booking_time=now(), paymentmode='$payment' WHERE customerphone_no=$customerphone";
	$sql1 = "INSERT into RECEIPT(car_id,carmodel,cost,customername,customerphone_no,booking_date,booking_time,paymentmode) values('$carid','$carmodel','$carcost','$customername','$customerphone',CURDATE(),now(),'$payment')";
	$conn->query($sql1);
	if ($conn->query($sql) === TRUE) {
    echo "New record created successfully. Thank YOU for shopping with us.!!<br>";
	$sql2 = "SELECT * FROM RECEIPT where customerphone_no=$customerphone";
	$result = $conn->query($sql2);

	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		echo "<table>";
		echo 
		"<tr><td>ID</td><td>". $row["id"].
		"</td></tr><td>CARID</td><td>". $row["car_id"].
		"</td></tr><td>MODEL</td><td>". $row["carmodel"].
		"</td></tr><td>PRICE</td><td>". $row["cost"].
		"</td></tr><td>NAME</td><td>". $row["customername"].
		"</td></tr><td>CONTACT</td><td>". $row["customerphone_no"].
		"</td></tr><td>DATE</td><td>". $row["booking_date"].
		"</td></tr><td>TIME</td><td>". $row["booking_time"].
		"</td></tr><td>PAYMENT</td><td>". $row["paymentmode"].
		"</td></tr><br>";
		}
	echo "</table><br><p>Print receipt</p>";
	echo "<a href='../index.html' class='btn' style='text-align:center'>LOG-OUT</a>";
	}else{
	echo"zero rows";
	
	}
	
} 
} 
$conn->close();
?>
<style>

table, td {  
  border: 1px solid black;
  text-align: left;
  color: black;
  padding: 3px;
  
  
}

table {
  border-collapse: collapse;
  width: 40%;
  align: center;
}
.btn{
	border:2px solid BLACK;
	padding:10px 30px;
	color:BLACK;
	text-decoration:none;
	transition:0.6s ease;
	cursor: pointer;
}

</style>