<html>
<head>
<title>booking</title>
<link href="../../style.css" rel="stylesheet" type="text/css">
<style>
table, td, th {  
  border: 1px solid white;
  text-align: left;
  color: white;
}

table {
  border-collapse: collapse;
  width: 100%;
  align: left;
}

th, td , input{
  padding: 3px;
}
.book{
color:black;
}
</style>
</head>
<body background='../../images/image8.jpg'>
<form action="../../php/booking.php" method="post">
    <div class="booking-box">

	  <h1>BOOKING</h1>
	  <br>
	  <table>
	  <tr>
		<th>CARID</th>
		<th>NAME</th>
	    <th>COMPANY</th>
		<th>MODEL</th>
		<th>COST</th>
		<th>COLOR</th>
	  </tr>
<?php
$conn=mysqli_connect("localhost","root","","carstore");
if ($conn-> connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT carid, carname, carcompany, carmodel, carcost, carcolor FROM cardetails where carname='Lamborghini'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {	
	echo "<tr>
	<td><input type='text' class='book' name='carid' value='".$row["carid"]."'</td>".
	"<td><input type='text' name='carname' value='".$row["carname"]."'</td>".
	"<td><input type='text' name='carcompany' value='".$row["carcompany"]."'</td>".
	"<td><input type='text' name='carmodel' value='".$row["carmodel"]."'</td>".
	"<td><input type='text' name='carcost' value='".$row["carcost"]."'</td>".
	"<td><input type='text' name='carcolor' value='".$row["carcolor"]."'</td>
	</tr>";
	}
	echo "</table>";
}else{
	echo"zero rows";
}
$conn->close();
?>
	  
	 <div style="text-align:center">
	  <br>
	  <h3>Confirm the Booking</h3>
	  <input type="text" placeholder="Enter customer_name" name="customername"  id='book'required>
	  <br>
	  <input type="text" placeholder="Enter phone" name="customerphone"  id='book' required>
	  <br>	  
	  <input type="radio" id="bookradio" name="payment" value="cash" required>CASH
	  <input type="radio" id="bookradio" name="payment" value="card" required>DEBIT/CREDIT CARD
	  <br>
	   <input class="btn" type="submit" name="submit" value="submit"></div>
	  <br>

</div>
</form>

</body>
</html>