// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyDff4eN979aP0QbTREJW8JjelXuwV2Z0kM",
  authDomain: "food-blog-comment.firebaseapp.com",
  projectId: "food-blog-comment",
  storageBucket: "food-blog-comment.appspot.com",
  messagingSenderId: "719825193869",
  appId: "1:719825193869:web:fa6d3d49cdab987a91cbc4"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);


//Referrence commentInfo collections
let commentInfo = firebase.database().ref("comment");
//listen for Submit
document.querySelector(".contact-form").addEventListener("submit",submitForm);
function submitForm(e){
  e.preventDefault();
//get input values
  let name = document.querySelector(".name").value;
  let comment = document.querySelector(".message").value;
  console.log(name, comment);
  saveCommentInfo(name, comment)
  document.querySelector(".contact-form").reset();
}

// Save infos to firebase
function saveCommentInfo(name,comment){
  let newCommentInfo = commentInfo.push();

  newCommentInfo.set({
    Name: name,
    Comment:comment
  });
}
